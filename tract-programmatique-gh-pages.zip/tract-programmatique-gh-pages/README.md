# tract-programmatique
Najat Vallaud-Belkacem, votre députée candidate de la gauche à Villeurbanne, les 11 et 18 juin prochain.

